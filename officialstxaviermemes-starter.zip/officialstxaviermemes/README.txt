# officialstxaviermemes

## Files
- `index.html` — responsive Instagram-style meme feed and upload page.
- `supabase-setup.sql` — database, storage bucket, and security policies.

## Make community uploads work
1. Create a free project at https://supabase.com/.
2. In the Supabase dashboard, open SQL Editor, create a query, paste `supabase-setup.sql`, and run it.
3. In Authentication > Providers, enable the Anonymous sign-in provider.
4. Open Project Settings > API. Copy the Project URL and anon/public key.
5. Open `index.html` in a text editor. Replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_PUBLIC_KEY` with those values.
6. Deploy the folder to Cloudflare Pages (Workers & Pages > Create > Pages > Direct Upload), or use another static host.

Do not put a Supabase service-role/secret key in this website. The anon/public key is intended for browser use; the SQL policies restrict inserts and image uploads to authenticated anonymous users and public reads.

## Notes
- Likes are currently saved per visitor's browser, not shared across devices.
- This starter does not include a moderation dashboard. Review posts and remove inappropriate content in Supabase.
- Because community uploads are public, publish a contact/report method and moderate content regularly. Avoid posting private student information or photos without permission.
